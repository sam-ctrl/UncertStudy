<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <meta charset="utf-8">
    <title>Date Accuracy Test</title>
    <meta name="author" content="Sam Cottrell" />
    <meta name="description" content="Date Recognition Test" />
    <meta name="Resource-type" content="Document" />


    <!-- Fonts -->
<!--     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'> -->
    <link href='https://fonts.googleapis.com/css?family=Nunito:300' rel='stylesheet' type='text/css'>

    <!-- Personal CSS -->
    <link href="graph.css" rel="stylesheet">



</head>

<body>
<span class="results" style="text-align: center;">
<?php
        include_once('connect.php');
        // $ip=@$_SERVER['REMOTE_ADDR'];

        // $initials = $_POST['initials'];

        $name = $_POST['name'];
        $age = $_POST['age'];
        $sex = $_POST['sex'];
      
        $availableMonths = $_POST['availableMonths'];
        $answerMonths = $_POST['answerMonths'];
        $inputMonths = $_POST['inputMonths'];
        $inputMonthsGraph = $_POST['inputMonthsGraph'];
        $clicknumberMonthsText = $_POST['clicknumberMonthsText'];

        $availableNineties = $_POST['availableNineties'];
        $answerNineties = $_POST['answerNineties'];
        $inputNineties = $_POST['inputNineties'];
        $inputNinetiesGraph = $_POST['inputNinetiesGraph'];
        $clicknumberNinetiesText = $_POST['clicknumberNinetiesText'];

        $availableTwentiethC = $_POST['availableTwentiethC'];
        $answerTwentiethC = $_POST['answerTwentiethC'];
        $inputTwentiethC = $_POST['inputTwentiethC'];
        $inputTwentiethCGraph = $_POST['inputTwentiethCGraph'];
        $clicknumberTwentiethCText = $_POST['clicknumberTwentiethCText'];

        $availableSecondM = $_POST['availableSecondM'];
        $answerSecondM = $_POST['answerSecondM'];
        $inputSecondM = $_POST['inputSecondM'];
        $inputSecondMGraph = $_POST['inputSecondMGraph'];
        $clicknumberSecondMText = $_POST['clicknumberSecondMText'];

        $availableBcad = $_POST['availableBcad'];
        $answerBcad = $_POST['answerBcad'];
        $inputBcad = $_POST['inputBcad'];
        $inputBcadGraph = $_POST['inputBcadGraph'];
        $clicknumberBcadText = $_POST['clicknumberBcadText'];

        $availableBcece = $_POST['availableBcece'];
        $answerBcece = $_POST['answerBcece'];
        $inputBcece = $_POST['inputBcece'];
        $inputBceceGraph = $_POST['inputBceceGraph'];
        $clicknumberBceceText = $_POST['clicknumberBceceText'];

        $scoreQuickfire1 = $_POST['scoreQuickfire1'];
        $scoreQuickfire2 = $_POST['scoreQuickfire2'];
        $scoreQuickfireTotal = $_POST['scoreQuickfireTotal'];

        $difficultyQuickfire1 = $_POST['difficultyQuickfire1'];
        $difficultyQuickfire2 = $_POST['difficultyQuickfire2'];


        $target1 = $_POST['target1'];
        $input1 = $_POST['input1'];
        $clicknumber1 = $_POST['clicknumber1'];
        $distance1 = $_POST['distance1'];
        $difficulty1 = $_POST['difficulty1'];

        $target2 = $_POST['target2'];
        $input2 = $_POST['input2'];
        $distance2 = $_POST['distance2'];
        $difficulty2 = $_POST['difficulty2'];

        $target3 = $_POST['target3'];
        $input3 = $_POST['input3'];
        $clicknumber3 = $_POST['clicknumber3'];
        $distance3 = $_POST['distance3'];
        $difficulty3 = $_POST['difficulty3'];

        $target4 = $_POST['target4'];
        $input4 = $_POST['input4'];
        $clicknumber4 = $_POST['clicknumber4'];
        $distance4 = $_POST['distance4'];
        $difficulty4 = $_POST['difficulty4'];

        $target5 = $_POST['target5'];
        $input5 = $_POST['input5'];
        $distance5 = $_POST['distance5'];
        $difficulty5 = $_POST['difficulty5'];

        $target6 = $_POST['target6'];
        $input6 = $_POST['input6'];
        $clicknumber6 = $_POST['clicknumber6'];
        $distance6 = $_POST['distance6'];
        $difficulty6 = $_POST['difficulty6'];

        $target7 = $_POST['target7'];
        $input7 = $_POST['input7'];
        $clicknumber7 = $_POST['clicknumber7'];
        $distance7 = $_POST['distance7'];
        $difficulty7 = $_POST['difficulty7'];

        $totaldistance = $_POST['totaldistance'];

        $pageloadDate = $_POST['pageloadDate'];
        $startTimeQuickfire1 = $_POST['startTimeQuickfire1'];
        $startTimeQuickfire2 = $_POST['startTimeQuickfire2'];
        $startTime1 = $_POST['startTime1'];
        $startTime2 = $_POST['startTime2'];
        $startTime3 = $_POST['startTime3'];
        $startTime4 = $_POST['startTime4'];
        $startTime5 = $_POST['startTime5'];
        $startTime6 = $_POST['startTime6'];
        $startTime7 = $_POST['startTime7'];
        $endTime = $_POST['endTime'];

        $pageloadWindowHeight = $_POST['pageloadWindowHeight'];
        $pageloadDocumentHeight = $_POST['pageloadDocumentHeight'];
        $pageloadWindowWidth = $_POST['pageloadWindowWidth'];
        $pageloadDocumentWidth = $_POST['pageloadDocumentWidth'];
        $pageloadScreenHeight = $_POST['pageloadScreenHeight'];
        $pageloadScreenWidth = $_POST['pageloadScreenWidth'];

        $quizendWindowHeight = $_POST['quizendWindowHeight'];
        $quizendDocumentHeight = $_POST['quizendDocumentHeight'];
        $quizendWindowWidth = $_POST['quizendWindowWidth'];
        $quizendDocumentWidth = $_POST['quizendDocumentWidth'];
        $quizendScreenHeight = $_POST['quizendScreenHeight'];
        $quizendScreenWidth = $_POST['quizendScreenWidth'];

         //$feedback = $_POST['feedback'];


        if(mysqli_query($dbc,"INSERT INTO user (name , age , sex , availableMonths , answerMonths , inputMonths , inputMonthsGraph , clicknumberMonthsText , availableNineties , answerNineties , inputNineties , inputNinetiesGraph , clicknumberNinetiesText , availableTwentiethC , answerTwentiethC , inputTwentiethC , inputTwentiethCGraph , clicknumberTwentiethCText , availableSecondM , answerSecondM , inputSecondM , inputSecondMGraph , clicknumberSecondMText , availableBcad , answerBcad , inputBcad , inputBcadGraph , clicknumberBcadText , availableBcece , answerBcece , inputBcece , inputBceceGraph , clicknumberBceceText , scoreQuickfire1 , scoreQuickfire2 , scoreQuickfireTotal , difficultyQuickfire1 , difficultyQuickfire2 , target1 , input1 , clicknumber1 , distance1 , difficulty1 , target2 , input2 , distance2 , difficulty2 , target3 , input3 , clicknumber3 , distance3 , difficulty3 , target4 , input4 , clicknumber4 , distance4 , difficulty4 , target5 , input5 , distance5 , difficulty5 , target6 , input6 , clicknumber6 , distance6 , difficulty6 , target7 , input7 , clicknumber7 , distance7 , difficulty7 , totaldistance , pageloadDate , startTimeQuickfire1 , startTimeQuickfire2 , startTime1 , startTime2 , startTime3 , startTime4 , startTime5 , startTime6 , startTime7 , endTime , pageloadWindowHeight , pageloadDocumentHeight , pageloadWindowWidth , pageloadDocumentWidth , pageloadScreenHeight , pageloadScreenWidth , quizendWindowHeight , quizendDocumentHeight , quizendWindowWidth , quizendDocumentWidth , quizendScreenHeight , quizendScreenWidth ) VALUES('$name', '$age', '$sex', '$availableMonths', '$answerMonths', '$inputMonths', '$inputMonthsGraph', '$clicknumberMonthsText', '$availableNineties', '$answerNineties', '$inputNineties', '$inputNinetiesGraph', '$clicknumberNinetiesText', '$availableTwentiethC', '$answerTwentiethC', '$inputTwentiethC', '$inputTwentiethCGraph', '$clicknumberTwentiethCText', '$availableSecondM', '$answerSecondM', '$inputSecondM', '$inputSecondMGraph', '$clicknumberSecondMText', '$availableBcad', '$answerBcad', '$inputBcad', '$inputBcadGraph', '$clicknumberBcadText', '$availableBcece', '$answerBcece', '$inputBcece', '$inputBceceGraph', '$clicknumberBceceText', '$scoreQuickfire1', '$scoreQuickfire2', '$scoreQuickfireTotal' , '$difficultyQuickfire1', '$difficultyQuickfire2', '$target1', '$input1', '$clicknumber1', '$distance1', '$difficulty1', '$target2', '$input2', '$distance2', '$difficulty2', '$target3', '$input3', '$clicknumber3', '$distance3', '$difficulty3', '$target4', '$input4', '$clicknumber4', '$distance4', '$difficulty4', '$target5', '$input5', '$distance5', '$difficulty5', '$target6', '$input6', '$clicknumber6', '$distance6', '$difficulty6', '$target7', '$input7', '$clicknumber7', '$distance7', '$difficulty7', '$totaldistance', '$pageloadDate', '$startTimeQuickfire1', '$startTimeQuickfire2', '$startTime1', '$startTime2', '$startTime3', '$startTime4', '$startTime5', '$startTime6', '$startTime7', '$endTime', '$pageloadWindowHeight', '$pageloadDocumentHeight', '$pageloadWindowWidth', '$pageloadDocumentWidth', '$pageloadScreenHeight', '$pageloadScreenWidth', '$quizendWindowHeight', '$quizendDocumentHeight', '$quizendWindowWidth', '$quizendDocumentWidth', '$quizendScreenHeight', '$quizendScreenWidth')"))
         echo "Thank you for your submission<br><br> You scored " . $scoreQuickfireTotal . "/12 on the quickfire round and were " . $totaldistance . " days out in total Please close the window or click the link to view the high scores <br><br><a href='index.php#welcome/1'>View High Scores</a> <br><br><a href='index.php#welcome'>Reset Experiment</a>";
        else
        echo ("Error description: " . mysqli_error($dbc));
?>
</span>
<script>

   setTimeout(function () {
       window.location.href = "index.php#welcome"; //will redirect to your blog page (an ex: blog.html)
    }, 30000);

</script>

</body>

</htmml>