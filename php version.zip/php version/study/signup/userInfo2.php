<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8">
    <title>Date Accuracy Test</title>
    <meta name="author" content="Sam Cottrell" />
    <meta name="description" content="Uncertainty Study" />
    <meta name="Resource-type" content="Document" />
    <!-- Fonts -->
    <!--     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'> -->
    <link href='https://fonts.googleapis.com/css?family=Nunito:300' rel='stylesheet' type='text/css'>
    <!-- Personal CSS -->
    <link href="graph.css" rel="stylesheet">
</head>

<body>
    <span class="results" style="text-align: center;">
        <?php
                // include_once('connect.php');
                $dbc = new mysqli('localhost', 'root', "password", "users");
                // $ip=@$_SERVER['REMOTE_ADDR'];

                // $initials = $_POST['initials'];

                $userName = "uname";
                $password = "pass";
                $name = "name";
                $email = "me@you.com";
                $sex = "male";
                $age = 18;
                $occupation = "dev";
                $route = "route";
                $tna = 'tna';
                $tnaDept = 'tnaDept';

                // header("Location: ../index.html");

                $query = "INSERT INTO user (name) VALUES ('$userName')";

                if ($dbc->query($query) === TRUE) {
                    echo "Thank you for your submission<br><br>" . $name . " <br> continue to study<a href='../study.php'>Reset Experiment</a>";
                    echo "
                        <script>
                            setTimeout(function () {
                                window.location.href = \"index.php#welcome\";
                            }, 10000);
                        </script>
                    ";
                } else {
                    echo ("Error description: " . mysqli_error($dbc));
                }
        ?>
    </span>
</body>
</htmml>