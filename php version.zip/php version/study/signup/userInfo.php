<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <meta charset="utf-8">
    <title>Date Accuracy Test</title>
    <meta name="author" content="Sam Cottrell" />
    <meta name="description" content="Uncertainty Study" />
    <meta name="Resource-type" content="Document" />


    <!-- Fonts -->
<!--     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'> -->
    <link href='https://fonts.googleapis.com/css?family=Nunito:300' rel='stylesheet' type='text/css'>

    <!-- Personal CSS -->
    <link href="graph.css" rel="stylesheet">



</head>

<body>
<span class="results" style="text-align: center;">
<?php
        include_once('connect.php');
        // $ip=@$_SERVER['REMOTE_ADDR'];

        // $initials = $_POST['initials'];

        $userName = $_POST['userName'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $sex = $_POST['sex'];
        $age = $_POST['age'];
        $occupation = $_POST['occupation'];
        $route = $_POST['route'];
        $tna = $_POST['tna'];
        $tnaDept = $_POST['tnaDept'];

        // header("Location: ../index.html");

        // $query = "INSERT INTO user (userName, password, name , email, age , sex , occupation , route , tna , tnaDept) VALUES ('$userName', '$password', '$name', '$email', '$age', '$sex', '$occupation', '$route', '$tna', '$tnaDept')"

        // if($dbc->query($sql) === TRUE) {
        //     echo "Thank you for your submission<br><br>" . $name . " <br> continue to study<a href='../study.php'>Reset Experiment</a>";
        // } else {
        //     echo ("Error description: " . mysqli_error($dbc));
        // }


        if(mysqli_query($dbc,"INSERT INTO user (userName, password, name , email, age , sex , occupation , route , tna , tnaDept) VALUES ('$userName', '$password', '$name', '$email', '$age', '$sex', '$occupation', '$route', '$tna', '$tnaDept')"))

         echo "Thank you for your submission<br><br>" . $name . " <br> continue to study<a href='../study.php'>Reset Experiment</a>";

        else

        echo ("Error description: " . mysqli_error($dbc));
?>
</span>
<script>

   setTimeout(function () {
       window.location.href = "index.php#welcome"; //will redirect to your blog page (an ex: blog.html)
    }, 10000);

</script>

</body>

</htmml>