<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <meta charset="utf-8">
    <title>Date Accuracy Test</title>
    <meta name="author" content="Sam Cottrell" />
    <meta name="description" content="Date Recognition Test" />
    <meta name="Resource-type" content="Document" />


    <!-- Fonts -->
<!--     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600' rel='stylesheet' type='text/css'> -->
    <link href='https://fonts.googleapis.com/css?family=Nunito:300' rel='stylesheet' type='text/css'>

    <!-- D3 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.8/d3.js"></script>

    <!-- Jquery  -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

    <!-- Bootstrap (for buttons) -->
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="../bootstrap/js/bootstrap.min.js"></script>

    <!-- Sweetalert for sweet alerts-->
    <script src="../dist/sweetalert2.min.js"></script> 
    <link rel="stylesheet" type="text/css" href="../dist/sweetalert2.css">

        <!-- Personal CSS -->
    <link href="../graph.css" rel="stylesheet">


    <style>

    </style>

    </head>

    <body>
      <div class="outer">
        <div class="middle">
          <div class="inner">

                <div class="section"><!--Personal information -->
                <br>
                <h1>Please fill in the following information</h1>
                <br>
          <form id="myForm" action="userInfo.php" method="post">
          <table align = "center" class = "signup"> 

              <col class="labels" />
              <col class="form" />

                <tr>
                <td>Username:<span style="color: red;">*</span></td> <td>
                <input type="text" name="userName" id="userName" placeholder="" /></td>
                </tr>
                <tr>
                <td>Password:<span style="color: red;">*</span></td> <td>
                <input type="password" name="password" id="password" placeholder="" /></td>
                </tr>
                <tr>
                <td>Name:</td> <td>
                <input type="text" name="name" id="name" /></td>
                </tr>
                <tr>
                <td>Email:</td> <td>
                <input type="text" name="email" id="email" /></td>
                </tr>
                <tr>
                <td>Gender:</select><span style="color: red;">*</span></td> <td>
                <select name = "sex" id = "sex">
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                  <option value="nodisclose">Prefer not to disclose</option>
                  <option selected disabled hidden value=''></option>
                </select>
                </td>
                </tr>
              <tr>
              <td>Age:<span style="color: red;">*</span></td> <td>
              <select name = "age" id = "age">
                  <option value="under20">Under 20</option>
                  <option value="20-24">20 - 24</option>
                  <option value="25-29">25 - 29</option>
                  <option value="30-34">30 - 34</option>
                  <option value="35-39">35 - 39</option>
                  <option value="40-44">40 - 44</option>
                  <option value="45-49">45 - 49</option>
                  <option value="50-54">50 - 54</option>
                  <option value="55-59">55 - 59</option>
                  <option value="60-64">60 - 64</option>
                  <option value="65-69">65 - 69</option>
                  <option value="over 69">Over 69</option>
                  <option selected disabled="disabled" hidden value=''></option>
              </select>
              </td>
                </tr>
              <tr>
              <td>Occupation:<span style="color:red;">*</span></td> <td>
              <select name = "occupation" id = "occupation">
                  <option value="DataProf">Data Proffesional</option>
                  <option value="Archivist">Archivist</option>
                  <option value="Historian">Historian</option>
                  <option value="Student">Student</option>
                  <option value="Other">Other</option>
                  <option selected disabled="disabled" hidden value=''></option>
              </select>
              </td>
                </tr>
              <tr>
            <td>How did you come across this study?:<span style="color:red;">*</span></td> <td>
              <select name = "route" id = "route">
                  <option value="reddit">Reddit</option>
                  <option value="mailgroup">Museum Computer Group</option>
                  <option value="email">E-mail</option>
                  <option value="Narnia">Narnia</option>

                  <option value="other">Other</option>
                  <option selected disabled="disabled" hidden value=''></option>
              </select>
              </td>
                </tr>
              <tr>
            <td>Are you employed at The National Archives?</td> <td>&nbsp
              <input type="radio" name="tna" value="y" id="yes">Yes &nbsp
              <input type="radio" name="tna" value="n" id="no" checked>No
              </td>
                </tr>
              <tr id = "tnaDepts" style="visibility:hidden; opacity:0">

            <td>Which department are you in?<span style="color:red;">*</span></td> <td>
              <select name = "tnaDept" id = "tnaDept">
                <option value="Advice & Records Knowledge">Advice & Records Knowledge</option>
                <option value="Archives Sector Development">Archives Sector Development</option>
                <option value="Business Continuity Management">Business Continuity Management</option>
                <option value="Business Coordination Unit">Business Coordination Unit</option>
                <option value="Catalogue and Taxonomy">Catalogue and Taxonomy</option>
                <option value="Chief Executive's Office">Chief Executive's Office</option>
                <option value="Collection Care">Collection Care</option>
                <option value="Corporate Planning">Corporate Planning</option>
                <option value="Digital Preservation">Digital Preservation</option>
                <option value="Document Services">Document Services</option>
                <option value="Education & Outreach"> Education & Outreach</option>
                <option value="Estates & Facilities">Estates & Facilities</option>
                <option value="Finance">Finance</option>
                <option value="Human Resources">Human Resources</option>
                <option value="Information Assurance & Cyber Security">Information Assurance & Cyber Security</option>
                <option value="Information Management">Information Management</option>
                <option value="Information Policy">Information Policy</option>
                <option value="IT Operations ">IT Operations </option>
                <option value="KIM Team">KIM Team</option>
                <option value="Learning and Development">Learning and Development</option>
                <option value="Legislation Services">Legislation Services</option>
                <option value="Licensing">Licensing</option>
                <option value="Marketing & Communications">Marketing & Communications</option>
                <option value="Procurement">Procurement</option>
                <option value="Programmes and Strategy">Programmes and Strategy</option>
                <option value="Quality and Excellence">Quality and Excellence</option>
                <option value="Research Team">Research Team</option>
                <option value="Security">Security</option>
                <option value="Strategic Projects"> Strategic Projects</option>
                <option value="Systems Development">Systems Development</option>
                <option value="Transfer and Access">Transfer and Access</option>
                <option value="Web Continuity">Web Continuity</option>
                <option value="Web Team">Web Team</option>
                <option value="Other">Other</option>
                <option selected disabled="disabled" hidden value='N/A'></option>
              </select>

              </td>
              </tr>
            
            </table>
            </form>

               <br><br>
               <span class="btn btn-success btn-lg" id="start">Continue</span> <br><br> <span class="fake-link" onclick="restartmessage()">Cancel</span>

              <button id="sub" class="btn btn-success btn-lg">Finish and submit</button>
              
              <span style = "font-size: 14px">
              <br><br>
              <span style="color: red;">*</span> mandatory field
              <br>
              Your name is not mandatory, it will not be used as part of the research (it is only used on the high scores list).
              <br>
               Please fill in your email address if you wish to be provided with a summary of the results at the conclusion of the investigation.
             </span>
          </div>

          </div>
      </div>
    </div>


<!--     The JS that sends the login information to the database -->
    <script src="formsubmit.js" type="text/javascript"></script>


    <script>

    //show/hide additional field

    d3.select("#yes")
      .on('click', function() {

        d3.selectAll("#tnaDepts")
          .style("visibility", "visible")
          .transition()
            .duration(300)
            .style("opacity", 1);
      })

    d3.select("#no")
      .on('click', function() {

        d3.selectAll("#tnaDepts")
          .transition()
            .duration(300)
            .style("opacity", 0)
             .each("end", removeOption);
      })

    
      function removeOption(){
          d3.selectAll("#tnaDepts")
          .style("visibility", "hidden")
      }

    //Validate the first page and timestamp when the experimet starts (to do)
    d3.select('#start')
        .on('click' , function() {

            var userName = document.getElementById('userName').value
            var password = document.getElementById('password').value
            var sex = document.getElementById('sex').value
            var age = document.getElementById('age').value
            var occupation = document.getElementById('occupation').value
            var route = document.getElementById('route').value

            if (userName && password && sex && age && occupation) { 

                //submit form and go to data gathering with user credentials

                formSubmit();

            } else {

                swal("Please make selections using the dropdowns", "The fields marked with a red asterix are mandatory", "error");

                return false;

            }
        });

    d3.select('#end')
        .on('click', function() {

            window.location.href = 'http://' + window.location.hostname + window.location.pathname;

        });


function formSubmit() {
 $.post( $("#myForm").attr("action"),
         $("#myForm :input").serializeArray(),
         function(info){ $("#result").html(info);
   });
//clearInput();
console.log("submitted")
};
 
$("#myForm").submit( function() {
  return false;
});
function clearInput() {
    $("#myForm :input").each( function() {
       $(this).val('');
    });
}

        </script>

    </body>

</html>